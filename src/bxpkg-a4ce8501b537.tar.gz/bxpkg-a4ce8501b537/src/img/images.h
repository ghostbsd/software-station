#include "icons/icons.h"
#include "m_icon_xpm.h"
#include "splash_xpm.h"
#include "install_xpm.h"
